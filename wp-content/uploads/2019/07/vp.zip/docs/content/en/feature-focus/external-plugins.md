# External Plugins and Themes

Please see the **[Integrations](../integrations/index.md)** section – the content has been moved and reorganized there.
