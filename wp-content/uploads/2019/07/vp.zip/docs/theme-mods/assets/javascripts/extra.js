
// remove header drop-shadow
document.getElementsByTagName("header")[0].removeAttribute("data-md-state");
