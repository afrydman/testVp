import * as React from 'react';

const Merge: React.StatelessComponent<{}> = () => (
  <li>
    <em>This is a merge commit. No files were changed in this commit.</em>
  </li>
);

export default Merge;
