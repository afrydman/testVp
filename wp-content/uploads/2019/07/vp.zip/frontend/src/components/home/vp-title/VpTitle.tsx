import * as React from 'react';

const VpTitle: React.StatelessComponent<{}> = () => (
  <h1 className='vp-header'>
    VersionPress
  </h1>
);

export default VpTitle;
