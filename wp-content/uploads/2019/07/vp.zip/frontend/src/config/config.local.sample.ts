// Copy and update values from config.ts

const config = {
  api: {
    root: 'http://localhost:8088',
    adminUrl: 'http://localhost:8088/wp-admin',
  },
};

export default config;
